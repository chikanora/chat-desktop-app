module org.oosd.chatclientappfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.oosd.chatclientappfx to javafx.fxml;
    exports org.oosd.chatclientappfx;
}